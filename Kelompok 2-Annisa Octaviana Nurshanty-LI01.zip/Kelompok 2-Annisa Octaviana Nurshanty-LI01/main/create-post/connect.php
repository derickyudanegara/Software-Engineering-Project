<?php

    $conn = mysqli_connect("localhost", "root", "") or die("Unable to conect");
    mysqli_select_db($conn, 'kelilingcom',);

?>