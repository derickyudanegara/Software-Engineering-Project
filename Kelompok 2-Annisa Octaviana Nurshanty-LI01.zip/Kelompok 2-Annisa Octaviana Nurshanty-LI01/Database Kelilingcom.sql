-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2020 at 07:25 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kelilingcom`
--

-- --------------------------------------------------------

--
-- Table structure for table `bandung2_forum`
--

CREATE TABLE `bandung2_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bandung_forum`
--

CREATE TABLE `bandung_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bandung_forum`
--

INSERT INTO `bandung_forum` (`commentID`, `username_forum`, `date`, `message`) VALUES
(3, 'DerickYudanegara', '2020-05-09 20:53:35', 'Pengalaman travel yang bagus'),
(4, 'MuhammadBioFranklyn', '2020-05-09 20:54:32', 'jadi ingin pergi ke Bandung'),
(6, 'FarhanRifanto', '2020-05-09 20:55:44', 'terimakasih sudah sharing'),
(7, 'AldoSaputra', '2020-05-09 20:56:19', 'saya juga ingin kesana'),
(8, 'AnnisaOctaviana', '2020-05-09 20:57:33', 'Foto-foto tempat wisatanya indah!'),
(9, 'Budi', '2020-05-09 21:13:43', 'nice'),
(10, 'guest', '2020-05-11 14:23:55', 'keren');

-- --------------------------------------------------------

--
-- Table structure for table `bogor_forum`
--

CREATE TABLE `bogor_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bogor_forum`
--

INSERT INTO `bogor_forum` (`commentID`, `username_forum`, `date`, `message`) VALUES
(1, 'guest', '2020-05-11 14:24:11', 'nice broo');

-- --------------------------------------------------------

--
-- Table structure for table `bondowoso_forum`
--

CREATE TABLE `bondowoso_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bukittinggi_forum`
--

CREATE TABLE `bukittinggi_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `denpasar_forum`
--

CREATE TABLE `denpasar_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `jogja_forum`
--

CREATE TABLE `jogja_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `karimunjawa_forum`
--

CREATE TABLE `karimunjawa_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `karimunjawa_forum`
--

INSERT INTO `karimunjawa_forum` (`commentID`, `username_forum`, `date`, `message`) VALUES
(2, 'orang', '2020-04-26 20:24:57', 'pantainya bagus sekali, airnya juga jernih. perjalanan mu sepertinya menyenangkan. terimakasih sudah berbagi..');

-- --------------------------------------------------------

--
-- Table structure for table `lembang_forum`
--

CREATE TABLE `lembang_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lembang_forum`
--

INSERT INTO `lembang_forum` (`commentID`, `username_forum`, `date`, `message`) VALUES
(1, 'guest', '2020-05-11 14:35:10', 'heloww');

-- --------------------------------------------------------

--
-- Table structure for table `malang_forum`
--

CREATE TABLE `malang_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `malang_forum`
--

INSERT INTO `malang_forum` (`commentID`, `username_forum`, `date`, `message`) VALUES
(1, 'messi', '2020-04-26 20:26:06', 'i <3 malang');

-- --------------------------------------------------------

--
-- Table structure for table `puncak_forum`
--

CREATE TABLE `puncak_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semarang2_forum`
--

CREATE TABLE `semarang2_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semarang_forum`
--

CREATE TABLE `semarang_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semarapura_forum`
--

CREATE TABLE `semarapura_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `singaraja_forum`
--

CREATE TABLE `singaraja_forum` (
  `commentID` int(11) NOT NULL,
  `username_forum` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `singaraja_forum`
--

INSERT INTO `singaraja_forum` (`commentID`, `username_forum`, `date`, `message`) VALUES
(1, 'guest', '2020-05-11 14:48:11', 'singarajaa');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(3, 'farhan', 'farhan'),
(5, 'adi', 'adi'),
(7, 'herman', 'herman'),
(8, 'orang', 'orang'),
(9, 'halo', 'halo'),
(10, 'adele', 'adele'),
(11, 'messi', 'messi'),
(12, '123', '123'),
(14, 'guest', 'guest'),
(17, 'MuhammadBioFranklyn', 'bio'),
(18, 'DerickYudanegara', 'derick'),
(19, 'FarhanRifanto', 'farhan'),
(20, 'AldoSaputra', 'aldo'),
(21, 'AnnisaOctaviana', 'annisa'),
(22, 'Budi', 'budi'),
(23, 'admin', 'admin'),
(24, 'derick12', 'derick');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bandung2_forum`
--
ALTER TABLE `bandung2_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `bandung_forum`
--
ALTER TABLE `bandung_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `bogor_forum`
--
ALTER TABLE `bogor_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `bondowoso_forum`
--
ALTER TABLE `bondowoso_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `bukittinggi_forum`
--
ALTER TABLE `bukittinggi_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `denpasar_forum`
--
ALTER TABLE `denpasar_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `jogja_forum`
--
ALTER TABLE `jogja_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `karimunjawa_forum`
--
ALTER TABLE `karimunjawa_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `lembang_forum`
--
ALTER TABLE `lembang_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `malang_forum`
--
ALTER TABLE `malang_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `puncak_forum`
--
ALTER TABLE `puncak_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `semarang2_forum`
--
ALTER TABLE `semarang2_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `semarang_forum`
--
ALTER TABLE `semarang_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `semarapura_forum`
--
ALTER TABLE `semarapura_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `singaraja_forum`
--
ALTER TABLE `singaraja_forum`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bandung2_forum`
--
ALTER TABLE `bandung2_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bandung_forum`
--
ALTER TABLE `bandung_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bogor_forum`
--
ALTER TABLE `bogor_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bondowoso_forum`
--
ALTER TABLE `bondowoso_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bukittinggi_forum`
--
ALTER TABLE `bukittinggi_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `denpasar_forum`
--
ALTER TABLE `denpasar_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jogja_forum`
--
ALTER TABLE `jogja_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `karimunjawa_forum`
--
ALTER TABLE `karimunjawa_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lembang_forum`
--
ALTER TABLE `lembang_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `malang_forum`
--
ALTER TABLE `malang_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `puncak_forum`
--
ALTER TABLE `puncak_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semarang2_forum`
--
ALTER TABLE `semarang2_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semarang_forum`
--
ALTER TABLE `semarang_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `semarapura_forum`
--
ALTER TABLE `semarapura_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `singaraja_forum`
--
ALTER TABLE `singaraja_forum`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
